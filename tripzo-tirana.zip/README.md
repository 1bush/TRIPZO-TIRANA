# Tripzo Tirana 🇦🇱

App turistik për vizitorët e Tiranës — transport, sightseeing, kafe/restorante, argëtim dhe itinerare, të gjitha në një vend.

## Tabet e aplikacionit

1. **Transporti** — 15 linjat urbane të Tiranës, autobusi i Aeroportit Rinas (çmimi, orari, frekuenca), kërkim linje.
2. **Eksploro** — Pikat turistike (histori, natyrë, art, familje) me foto, orare dhe çmime.
3. **Ha & Pi** — Restorante, kafe dhe klube me filtra zone/çmimi/vibe.
4. **Argëtim** — Teatro, kinema, koncerte, festivale me kalendar.
5. **Itinerare** — Gjenerues automatik planesh 1/3/7-ditore, me opsion ndarjeje (share).
6. **Info Praktike** — Numra urgjence, konvertues valute live (EUR↔Lek), fraza bazë shqip, këshilla sigurie.

## Tech Stack

- React 19 + TypeScript + Vite
- React Router (HashRouter, gati për static hosting/GitHub Pages)
- Tailwind CSS v4
- lucide-react (ikona)
- Open-Meteo API (mot live, falas, pa API key)
- Frankfurter API (kurse këmbimi valutor live, falas)

## Zhvillim lokal

```bash
npm install
npm run dev
```

## Build për prodhim

```bash
npm run build
```

Output në `dist/`. HashRouter e bën app-in gati për GitHub Pages ose çdo static host pa konfigurim shtesë të serverit.

## Të dhënat

Aktualisht të gjitha të dhënat (linjat e autobusit, POI, restorante, evente) janë **demo/statike** në `src/data/`. Për prodhim:

- **Linjat e autobusëve**: importo GeoJSON-in zyrtar nga [opendata.tirana.al](https://opendata.tirana.al) (dataset: "Transporti publik në Tiranë i gjeoreferencuar", 15 linja, 451 stacione, CC-BY) dhe zëvendëso `src/data/busLines.ts`.
- **POI, restorante, evente**: mund të lidhen me Supabase për menaxhim dinamik dhe review/rating nga komuniteti.

## Hapat e ardhshëm (roadmap)

- [ ] Import i GeoJSON zyrtar për stacionet e sakta GPS
- [ ] Backend Supabase (bus_lines, poi, restaurants, events, reviews, user_favorites)
- [ ] Autentikim përdoruesish + sync favorites nëpër pajisje
- [ ] Review/rating nga komuniteti
- [ ] Mënyrë offline (service worker / cache API)
- [ ] Hartë interaktive me Leaflet për çdo tab
- [ ] Toggle gjuhe (Shqip/Anglisht)
- [ ] Publikim si PWA (installable)
