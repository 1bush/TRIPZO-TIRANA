import type { FoodPlace } from '../types';

export const foodPlaces: FoodPlace[] = [
  {
    id: 'f-1', name: 'Oda', type: 'restorant', zone: 'Kalaja e Tiranës',
    cuisine: 'Tradicionale shqiptare', price: 2, vibe: 'familjar', hours: '10:00 - 23:00',
    lat: 41.3262, lng: 19.8152, image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800', rating: 4.6,
  },
  {
    id: 'f-2', name: 'Komiteti Kafe Muzeum', type: 'kafe', zone: 'Ish-Bllok',
    cuisine: 'Kafe & Vintage', price: 2, vibe: 'romantik', hours: '08:00 - 00:00',
    lat: 41.3225, lng: 19.8125, image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800', rating: 4.5,
  },
  {
    id: 'f-3', name: 'Sky Club Tower Bar', type: 'klub', zone: 'Qendër',
    cuisine: 'Cocktail bar / Panoramë', price: 3, vibe: 'nightlife', hours: '18:00 - 02:00',
    lat: 41.3285, lng: 19.8195, image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=800', rating: 4.4,
  },
  {
    id: 'f-4', name: 'Era Restaurant', type: 'restorant', zone: 'Ish-Bllok',
    cuisine: 'Mesdhetare fine-dining', price: 3, vibe: 'romantik', hours: '12:00 - 23:30',
    lat: 41.3235, lng: 19.8140, image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800', rating: 4.7,
  },
  {
    id: 'f-5', name: 'Sophie Deli & Café', type: 'kafe', zone: 'Ish-Bllok',
    cuisine: 'Brunch & Pastiçeri', price: 2, vibe: 'casual', hours: '07:30 - 22:00',
    lat: 41.3228, lng: 19.8135, image: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=800', rating: 4.6,
  },
  {
    id: 'f-6', name: 'Pizza E Vjeter', type: 'restorant', zone: 'Qendër',
    cuisine: 'Pizza & Italiane', price: 1, vibe: 'familjar', hours: '11:00 - 23:00',
    lat: 41.3300, lng: 19.8210, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800', rating: 4.3,
  },
  {
    id: 'f-7', name: 'Radio Bar', type: 'klub', zone: 'Ish-Bllok',
    cuisine: 'Live music / Bar', price: 2, vibe: 'nightlife', hours: '19:00 - 03:00',
    lat: 41.3220, lng: 19.8118, image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800', rating: 4.5,
  },
  {
    id: 'f-8', name: 'Mullixhiu', type: 'restorant', zone: 'Parku i Liqenit',
    cuisine: 'Shqiptare moderne (farm-to-table)', price: 3, vibe: 'romantik', hours: '12:00 - 23:00',
    lat: 41.3125, lng: 19.8228, image: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=800', rating: 4.8,
  },
];
