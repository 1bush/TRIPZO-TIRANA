import type { BusLine } from '../types';

// Të dhëna bazuar në emrat zyrtarë të linjave nga Bashkia Tiranë (Vendim KB Nr. 39/2016)
// dhe harta e Urbanit (urbani.tirana.al). Koordinatat e stacioneve janë të përafërta
// për qëllime demonstrimi — për koordinata të sakta GPS, importo GeoJSON-in zyrtar nga
// https://opendata.tirana.al (dataset: "Transporti publik në Tiranë i gjeoreferencuar").
export const busLines: BusLine[] = [
  {
    id: 'l1', number: '1', name: 'Selitë – Kristal – Qendër – Stacioni i Trenit – Allias',
    color: '#0b6e8f', from: 'Selitë', to: 'Allias',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 8, priceLek: 40,
    stops: [
      { id: 's1-1', name: 'Selitë', lat: 41.3667, lng: 19.8500 },
      { id: 's1-2', name: 'Kristal', lat: 41.3450, lng: 19.8300 },
      { id: 's1-3', name: 'Sheshi Skënderbej (Qendër)', lat: 41.3275, lng: 19.8187 },
      { id: 's1-4', name: 'Stacioni i Trenit', lat: 41.3306, lng: 19.8172 },
      { id: 's1-5', name: 'Allias', lat: 41.3600, lng: 19.7900 },
    ],
  },
  {
    id: 'l2', number: '2', name: 'Teg – Sauk – Kopshti Zoologjik – Ish Stacioni i Trenit',
    color: '#f2994a', from: 'TEG', to: 'Ish Stacioni i Trenit',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 10, priceLek: 40,
    stops: [
      { id: 's2-1', name: 'TEG', lat: 41.3020, lng: 19.8400 },
      { id: 's2-2', name: 'Sauk', lat: 41.2980, lng: 19.8100 },
      { id: 's2-3', name: 'Kopshti Zoologjik', lat: 41.3400, lng: 19.8350 },
      { id: 's2-4', name: 'Ish Stacioni i Trenit', lat: 41.3306, lng: 19.8172 },
    ],
  },
  {
    id: 'l3a', number: '3A', name: 'Kashar – Yzberisht – Qendër – Astir',
    color: '#2f9e44', from: 'Kashar', to: 'Astir',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 9, priceLek: 40,
    stops: [
      { id: 's3-1', name: 'Kashar', lat: 41.3550, lng: 19.7200 },
      { id: 's3-2', name: 'Yzberisht', lat: 41.3450, lng: 19.7500 },
      { id: 's3-3', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
      { id: 's3-4', name: 'Astir', lat: 41.3050, lng: 19.8500 },
    ],
  },
  {
    id: 'l4', number: '4', name: 'Qendër – QTU – Megatek – City Park',
    color: '#e64980', from: 'Qendër', to: 'City Park',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 7, priceLek: 40,
    stops: [
      { id: 's4-1', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
      { id: 's4-2', name: 'QTU', lat: 41.3150, lng: 19.8300 },
      { id: 's4-3', name: 'Megatek', lat: 41.3080, lng: 19.8350 },
      { id: 's4-4', name: 'City Park', lat: 41.2950, lng: 19.8450 },
    ],
  },
  {
    id: 'l5a', number: '5A', name: 'Ish-Kombinati i Autotraktorëve – Qendër',
    color: '#9c36b5', from: 'Ish-Kombinati i Autotraktorëve', to: 'Qendër',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 6, priceLek: 40,
    stops: [
      { id: 's5-1', name: 'Ish-Kombinati i Autotraktorëve', lat: 41.3550, lng: 19.7900 },
      { id: 's5-2', name: 'Rruga e Kavajës', lat: 41.3300, lng: 19.7950 },
      { id: 's5-3', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
    ],
  },
  {
    id: 'l5b', number: '5B', name: 'Institut – Qendër',
    color: '#7048e8', from: 'Institut', to: 'Qendër',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 10, priceLek: 40,
    stops: [
      { id: 's5b-1', name: 'Institut', lat: 41.3500, lng: 19.7700 },
      { id: 's5b-2', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
    ],
  },
  {
    id: 'l6', number: '6', name: 'Laprakë – Qendër',
    color: '#1c7ed6', from: 'Laprakë', to: 'Qendër',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 8, priceLek: 40,
    stops: [
      { id: 's6-1', name: 'Laprakë', lat: 41.3400, lng: 19.7850 },
      { id: 's6-2', name: 'Rruga e Durrësit', lat: 41.3320, lng: 19.8000 },
      { id: 's6-3', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
    ],
  },
  {
    id: 'l8a', number: '8A', name: 'Qendër – T.E.G',
    color: '#f08c00', from: 'Qendër', to: 'TEG',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 9, priceLek: 40,
    stops: [
      { id: 's8-1', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
      { id: 's8-2', name: 'Rruga e Elbasanit', lat: 41.3150, lng: 19.8350 },
      { id: 's8-3', name: 'TEG', lat: 41.3020, lng: 19.8400 },
    ],
  },
  {
    id: 'l9a', number: '9A', name: 'Qytet Studenti – Jordan Misja',
    color: '#0ca678', from: 'Qytet Studenti', to: 'Jordan Misja',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 11, priceLek: 40,
    stops: [
      { id: 's9-1', name: 'Qytet Studenti', lat: 41.3230, lng: 19.8280 },
      { id: 's9-2', name: 'Jordan Misja', lat: 41.3350, lng: 19.8050 },
    ],
  },
  {
    id: 'l10a', number: '10A/10B', name: 'Qendër – Mihal Grameno',
    color: '#495057', from: 'Qendër', to: 'Mihal Grameno',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 10, priceLek: 40,
    stops: [
      { id: 's10-1', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
      { id: 's10-2', name: 'Mihal Grameno', lat: 41.3380, lng: 19.8380 },
    ],
  },
  {
    id: 'l11', number: '11', name: 'Porcelani',
    color: '#c92a2a', from: 'Qendër', to: 'Porcelan',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 12, priceLek: 40,
    stops: [
      { id: 's11-1', name: 'Sheshi Skënderbej', lat: 41.3275, lng: 19.8187 },
      { id: 's11-2', name: 'Porcelan', lat: 41.3100, lng: 19.7950 },
    ],
  },
  {
    id: 'l12', number: '12', name: 'Uzina Dinamo – Sharrë',
    color: '#5c940d', from: 'Uzina Dinamo', to: 'Sharrë',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 13, priceLek: 40,
    stops: [
      { id: 's12-1', name: 'Uzina Dinamo', lat: 41.2950, lng: 19.7900 },
      { id: 's12-2', name: 'Sharrë', lat: 41.2700, lng: 19.7700 },
    ],
  },
  {
    id: 'l13', number: '13', name: 'Tirana e Re – Stacioni i Trenit',
    color: '#e8590c', from: 'Tirana e Re', to: 'Stacioni i Trenit',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 9, priceLek: 40,
    stops: [
      { id: 's13-1', name: 'Tirana e Re', lat: 41.3450, lng: 19.8450 },
      { id: 's13-2', name: 'Stacioni i Trenit', lat: 41.3306, lng: 19.8172 },
    ],
  },
  {
    id: 'l15a', number: '15A', name: 'Kombinat – Tufinë',
    color: '#0c8599', from: 'Kombinat', to: 'Tufinë',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 11, priceLek: 40,
    stops: [
      { id: 's15-1', name: 'Kombinat', lat: 41.3000, lng: 19.7800 },
      { id: 's15-2', name: 'Tufinë', lat: 41.3800, lng: 19.8200 },
    ],
  },
  {
    id: 'l16', number: '16', name: 'Kombinat – Kinostudio',
    color: '#d6336c', from: 'Kombinat', to: 'Kinostudio',
    firstDeparture: '06:00', lastDeparture: '23:00', avgWaitMin: 10, priceLek: 40,
    stops: [
      { id: 's16-1', name: 'Kombinat', lat: 41.3000, lng: 19.7800 },
      { id: 's16-2', name: 'Kinostudio', lat: 41.3150, lng: 19.7750 },
    ],
  },
];

export const rinasAirportInfo = {
  name: 'Autobusi i Aeroportit Rinas',
  from: 'Sheshi Skënderbej',
  to: 'Aeroporti Nënë Tereza (Rinas)',
  priceLek: 400,
  frequencyMin: 40,
  firstDeparture: '05:20',
  lastDeparture: '23:00',
  durationMin: 35,
};
