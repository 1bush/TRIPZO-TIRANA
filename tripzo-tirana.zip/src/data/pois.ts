import type { POI } from '../types';

export const pois: POI[] = [
  {
    id: 'poi-1', name: 'Sheshi Skënderbej', category: 'histori',
    description: 'Sheshi kryesor i Tiranës, zemra e qytetit me statujën e Skënderbeut dhe Xhaminë e Et\'hem Beut.',
    lat: 41.3275, lng: 19.8187, priceInfo: 'Falas', hours: '24 orë',
    image: 'https://images.unsplash.com/photo-1600100897230-4b357f831f4b?w=800',
    rating: 4.7,
  },
  {
    id: 'poi-2', name: 'Kalaja e Tiranës (Justiniani)', category: 'histori',
    description: 'Mbetjet e kalasë bizantine me dyqane artizanale dhe restorante brenda mureve.',
    lat: 41.3260, lng: 19.8150, priceInfo: 'Falas (hyrje e jashtme)', hours: '09:00 - 22:00',
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?w=800',
    rating: 4.4,
  },
  {
    id: 'poi-3', name: "Bunk'Art 2", category: 'histori',
    description: 'Muze nëntokësor në ish-bunkerin e Ministrisë së Brendshme, historia e Sigurimit të Shtetit.',
    lat: 41.3283, lng: 19.8175, priceInfo: '500 Lekë', hours: '09:00 - 16:00',
    image: 'https://images.unsplash.com/photo-1595007964593-2b1d3f2f4b1b?w=800',
    rating: 4.6,
  },
  {
    id: 'poi-4', name: 'Piramida e Tiranës', category: 'art',
    description: 'Ish-muzeu i diktatorit, sot i rikonstruktuar si qendër inovacioni dhe arti dixhital.',
    lat: 41.3247, lng: 19.8225, priceInfo: 'Falas (zonat publike)', hours: '08:00 - 22:00',
    image: 'https://images.unsplash.com/photo-1449034446853-66c86144b0ad?w=800',
    rating: 4.3,
  },
  {
    id: 'poi-5', name: 'Mali i Dajtit (Teleferiku Dajti Ekspres)', category: 'natyre',
    description: 'Teleferik 15-minutësh drejt Parkut Kombëtar të Dajtit, pamje panoramike mbi Tiranën.',
    lat: 41.3660, lng: 19.9200, priceInfo: '1500 Lekë (vajtje-ardhje)', hours: '09:00 - 21:00',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800',
    rating: 4.8,
  },
  {
    id: 'poi-6', name: "Ish-Blloku", category: 'art',
    description: 'Ish-zona e kufizuar e elitës komuniste, sot lagja më e gjallë me bare, kafe dhe butik-e.',
    lat: 41.3230, lng: 19.8130, priceInfo: 'Falas', hours: '24 orë',
    image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800',
    rating: 4.5,
  },
  {
    id: 'poi-7', name: 'Parku i Liqenit Artificial', category: 'natyre',
    description: 'Parku më i madh i qytetit, ideal për shëtitje, çiklizëm dhe piknik familjar.',
    lat: 41.3130, lng: 19.8230, priceInfo: 'Falas', hours: '24 orë',
    image: 'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?w=800',
    rating: 4.6,
  },
  {
    id: 'poi-8', name: 'Muzeu Historik Kombëtar', category: 'histori',
    description: 'Muzeu më i madh i vendit, mozaiku ikonik në fasadë dhe koleksione nga antikiteti te pavarësia.',
    lat: 41.3277, lng: 19.8180, priceInfo: '500 Lekë', hours: '09:00 - 17:00',
    image: 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=800',
    rating: 4.2,
  },
  {
    id: 'poi-9', name: 'Parku i Madh (Rinia)', category: 'familje',
    description: 'Zonë e gjelbër me lodra për fëmijë, pedalina dhe kafe familjare pranë liqenit.',
    lat: 41.3080, lng: 19.8300, priceInfo: 'Falas', hours: '24 orë',
    image: 'https://images.unsplash.com/photo-1560785496-3c9d27877182?w=800',
    rating: 4.5,
  },
  {
    id: 'poi-10', name: 'Xhamia e Madhe e Tiranës (Namazgah)', category: 'histori',
    description: 'Një nga xhamitë më të mëdha në Ballkan, arkitekturë moderne me elemente osmane.',
    lat: 41.3290, lng: 19.8210, priceInfo: 'Falas', hours: '06:00 - 22:00',
    image: 'https://images.unsplash.com/photo-1564769662646-4d8f6c8c5312?w=800',
    rating: 4.7,
  },
];
