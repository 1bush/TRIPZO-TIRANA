import type { EventItem } from '../types';

export const events: EventItem[] = [
  {
    id: 'e-1', title: 'Mrekullia (Shfaqje dramatike)', category: 'teatro',
    venue: 'Teatri Kombëtar', date: '2026-07-12', time: '20:00', priceLek: 500,
    image: 'https://images.unsplash.com/photo-1503095396549-807759245b35?w=800',
  },
  {
    id: 'e-2', title: 'Netët e Verës në Piramidë', category: 'festival',
    venue: 'Piramida e Tiranës', date: '2026-07-15', time: '19:00', priceLek: 'falas',
    image: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800',
  },
  {
    id: 'e-3', title: 'Koncert Xhaz nën Yje', category: 'koncert',
    venue: 'Kalaja e Tiranës', date: '2026-07-18', time: '21:00', priceLek: 800,
    image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800',
  },
  {
    id: 'e-4', title: 'Filma nën Qiell të Hapur', category: 'kinema',
    venue: 'Parku i Liqenit', date: '2026-07-20', time: '21:30', priceLek: 'falas',
    image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800',
  },
];
