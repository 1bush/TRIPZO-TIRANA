import { useMemo, useState } from 'react';
import { Heart, MapPin, Clock, Star } from 'lucide-react';
import TopBar from '../components/TopBar';
import { pois } from '../data/pois';
import { useFavorites } from '../lib/useFavorites';
import type { POICategory } from '../types';

const categories: { key: POICategory | 'all'; label: string }[] = [
  { key: 'all', label: 'Të gjitha' },
  { key: 'histori', label: 'Histori' },
  { key: 'natyre', label: 'Natyrë' },
  { key: 'art', label: 'Art' },
  { key: 'familje', label: 'Familje' },
];

export default function ExplorePage() {
  const [cat, setCat] = useState<POICategory | 'all'>('all');
  const { toggleFavorite, isFavorite } = useFavorites();

  const filtered = useMemo(
    () => (cat === 'all' ? pois : pois.filter((p) => p.category === cat)),
    [cat]
  );

  return (
    <div className="pb-24">
      <TopBar title="Eksploro" subtitle="Pikat turistike të Tiranës" />

      <div className="px-4 -mt-3 flex gap-2 overflow-x-auto pb-1">
        {categories.map((c) => (
          <button
            key={c.key}
            onClick={() => setCat(c.key)}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium shadow-sm transition-colors ${
              cat === c.key
                ? 'bg-[var(--color-adriatic)] text-white'
                : 'bg-white text-gray-600'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 grid gap-4">
        {filtered.map((poi) => (
          <div key={poi.id} className="bg-white rounded-2xl overflow-hidden shadow-sm">
            <div className="relative">
              <img src={poi.image} alt={poi.name} className="w-full h-40 object-cover" />
              <button
                onClick={() => toggleFavorite(poi.id)}
                className="absolute top-3 right-3 bg-white/90 rounded-full p-2"
              >
                <Heart
                  size={16}
                  className={isFavorite(poi.id) ? 'fill-[var(--color-sunset)] text-[var(--color-sunset)]' : 'text-gray-400'}
                />
              </button>
              <div className="absolute bottom-3 left-3 bg-black/50 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                <Star size={12} className="fill-yellow-400 text-yellow-400" /> {poi.rating}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-gray-800">{poi.name}</h3>
              <p className="text-sm text-gray-500 mt-1 line-clamp-2">{poi.description}</p>
              <div className="flex gap-3 mt-3 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <Clock size={12} /> {poi.hours}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin size={12} /> {poi.priceInfo}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
