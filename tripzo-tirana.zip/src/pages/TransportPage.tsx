import { useMemo, useState } from 'react';
import { Clock, Coins, Plane, MapPin, Search } from 'lucide-react';
import TopBar from '../components/TopBar';
import { busLines, rinasAirportInfo } from '../data/busLines';

export default function TransportPage() {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return busLines;
    return busLines.filter(
      (l) =>
        l.number.toLowerCase().includes(q) ||
        l.name.toLowerCase().includes(q) ||
        l.from.toLowerCase().includes(q) ||
        l.to.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="pb-24">
      <TopBar title="Transporti" subtitle="Linjat urbane të Tiranës" />

      <div className="px-4 -mt-3">
        <div className="bg-white rounded-2xl shadow-sm flex items-center gap-2 px-4 py-3">
          <Search size={18} className="text-gray-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Kërko linjë ose destinacion..."
            className="flex-1 outline-none text-sm"
          />
        </div>
      </div>

      {/* Karta e Aeroportit Rinas */}
      <div className="px-4 mt-4">
        <div className="bg-gradient-to-br from-[var(--color-sunset)] to-[var(--color-sunset-light)] rounded-2xl p-4 text-white shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <Plane size={20} />
            <span className="font-bold">{rinasAirportInfo.name}</span>
          </div>
          <p className="text-sm text-white/90 mb-3">
            {rinasAirportInfo.from} → {rinasAirportInfo.to}
          </p>
          <div className="flex flex-wrap gap-3 text-sm">
            <span className="flex items-center gap-1 bg-white/20 rounded-full px-3 py-1">
              <Coins size={14} /> {rinasAirportInfo.priceLek} Lekë
            </span>
            <span className="flex items-center gap-1 bg-white/20 rounded-full px-3 py-1">
              <Clock size={14} /> ~{rinasAirportInfo.durationMin} min udhëtim
            </span>
            <span className="flex items-center gap-1 bg-white/20 rounded-full px-3 py-1">
              Çdo {rinasAirportInfo.frequencyMin} min
            </span>
          </div>
          <p className="text-xs text-white/80 mt-2">
            Orari: {rinasAirportInfo.firstDeparture} - {rinasAirportInfo.lastDeparture} (të dyja drejtimet)
          </p>
        </div>
      </div>

      {/* Info bazë transporti urban */}
      <div className="px-4 mt-4 flex gap-3">
        <div className="flex-1 bg-white rounded-xl p-3 text-center shadow-sm">
          <p className="text-xs text-gray-500">Çmimi</p>
          <p className="font-bold text-[var(--color-adriatic)]">40 Lekë</p>
        </div>
        <div className="flex-1 bg-white rounded-xl p-3 text-center shadow-sm">
          <p className="text-xs text-gray-500">Orari</p>
          <p className="font-bold text-[var(--color-adriatic)]">06:00-23:00</p>
        </div>
        <div className="flex-1 bg-white rounded-xl p-3 text-center shadow-sm">
          <p className="text-xs text-gray-500">Pritja</p>
          <p className="font-bold text-[var(--color-adriatic)]">3-13 min</p>
        </div>
      </div>

      {/* Lista e linjave */}
      <div className="px-4 mt-4 space-y-3">
        <h2 className="font-bold text-gray-700">Linjat urbane ({filtered.length})</h2>
        {filtered.map((line) => (
          <div key={line.id} className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                style={{ backgroundColor: line.color }}
              >
                {line.number}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm text-gray-800 truncate">{line.name}</p>
                <p className="text-xs text-gray-500">
                  {line.from} → {line.to}
                </p>
              </div>
            </div>
            <div className="flex gap-3 mt-3 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <Clock size={12} /> pritje ~{line.avgWaitMin} min
              </span>
              <span className="flex items-center gap-1">
                <MapPin size={12} /> {line.stops.length} stacione (demo)
              </span>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <p className="text-center text-gray-400 text-sm py-6">Asnjë linjë nuk u gjet.</p>
        )}
      </div>

      <p className="px-4 mt-4 text-[11px] text-gray-400 leading-relaxed">
        Të dhënat e linjave janë demonstrative. Për stacione dhe koordinata GPS të sakta, importo
        dataset-in zyrtar nga Bashkia Tiranë (opendata.tirana.al).
      </p>
    </div>
  );
}
