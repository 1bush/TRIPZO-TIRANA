import { useState } from 'react';
import { Share2, Sparkles } from 'lucide-react';
import TopBar from '../components/TopBar';
import { pois } from '../data/pois';
import { foodPlaces } from '../data/foodPlaces';

const durations = [
  { key: 1, label: '1 Ditë' },
  { key: 3, label: '3 Ditë' },
  { key: 7, label: '1 Javë' },
];

// Gjenerues i thjeshtë itinerari: shpërndan POI + vende ushqimi nëpër ditë
function generatePlan(days: number) {
  const plan: { day: number; morning: string; lunch: string; afternoon: string; dinner: string }[] = [];
  for (let d = 0; d < days; d++) {
    const morning = pois[(d * 2) % pois.length];
    const afternoon = pois[(d * 2 + 1) % pois.length];
    const lunch = foodPlaces[(d * 2) % foodPlaces.length];
    const dinner = foodPlaces[(d * 2 + 1) % foodPlaces.length];
    plan.push({
      day: d + 1,
      morning: morning.name,
      lunch: lunch.name,
      afternoon: afternoon.name,
      dinner: dinner.name,
    });
  }
  return plan;
}

export default function ItineraryPage() {
  const [selectedDays, setSelectedDays] = useState<number | null>(null);
  const plan = selectedDays ? generatePlan(selectedDays) : null;

  const handleShare = () => {
    const text = plan
      ?.map(
        (p) =>
          `Dita ${p.day}: 🌅 ${p.morning} → 🍽️ ${p.lunch} → 🏛️ ${p.afternoon} → 🌆 ${p.dinner}`
      )
      .join('\n');
    if (navigator.share && text) {
      navigator.share({ title: 'Itinerari im në Tiranë - Tripzo Tirana', text });
    } else if (text) {
      navigator.clipboard.writeText(text);
      alert('Itinerari u kopjua! E gati për ta ndarë me miqtë.');
    }
  };

  return (
    <div className="pb-24">
      <TopBar title="Itinerare" subtitle="Plani yt për Tiranën" />

      <div className="px-4 -mt-3">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <p className="text-sm font-semibold text-gray-700 mb-3">Sa ditë do të qëndrosh?</p>
          <div className="flex gap-2">
            {durations.map((d) => (
              <button
                key={d.key}
                onClick={() => setSelectedDays(d.key)}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${
                  selectedDays === d.key
                    ? 'bg-[var(--color-adriatic)] text-white'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {plan && (
        <div className="px-4 mt-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-gray-700 flex items-center gap-1">
              <Sparkles size={16} className="text-[var(--color-sunset)]" /> Itinerari yt
            </h2>
            <button
              onClick={handleShare}
              className="flex items-center gap-1 text-sm text-[var(--color-adriatic)] font-medium"
            >
              <Share2 size={14} /> Ndaj
            </button>
          </div>
          {plan.map((p) => (
            <div key={p.day} className="bg-white rounded-2xl p-4 shadow-sm">
              <p className="font-bold text-[var(--color-adriatic)] mb-2">Dita {p.day}</p>
              <ul className="text-sm text-gray-600 space-y-1.5">
                <li>🌅 <span className="font-medium">Mëngjes:</span> {p.morning}</li>
                <li>🍽️ <span className="font-medium">Drekë:</span> {p.lunch}</li>
                <li>🏛️ <span className="font-medium">Pasdite:</span> {p.afternoon}</li>
                <li>🌆 <span className="font-medium">Darkë:</span> {p.dinner}</li>
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
