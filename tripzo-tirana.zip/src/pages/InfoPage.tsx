import { useEffect, useState } from 'react';
import { Phone, ArrowLeftRight, MessageCircle, Wifi, ShieldAlert } from 'lucide-react';
import TopBar from '../components/TopBar';

const emergencyNumbers = [
  { label: 'Policia', number: '129' },
  { label: 'Ambulanca', number: '127' },
  { label: 'Zjarrfikësja', number: '128' },
];

const phrases = [
  { sq: 'Përshëndetje', en: 'Hello' },
  { sq: 'Faleminderit', en: 'Thank you' },
  { sq: 'Sa kushton?', en: 'How much is it?' },
  { sq: 'Ku është...?', en: 'Where is...?' },
  { sq: 'Ju lutem', en: 'Please' },
  { sq: 'Nuk flas shqip', en: "I don't speak Albanian" },
];

const safetyTips = [
  'Tirana është përgjithësisht e sigurt, por ki kujdes nga xhepat në zona të mbushura.',
  'Taksi zyrtare kanë taksimetër — pyet çmimin përpara nisjes nëse s\'ka taksimetër.',
  'Uji i rubinetit pihet në shumicën e zonave, por uji i shishes këshillohet për stomak të ndjeshëm.',
  'Numri i emergjencës universal në Shqipëri: 112.',
];

export default function InfoPage() {
  const [amount, setAmount] = useState('10');
  const [rate, setRate] = useState<number | null>(null);

  useEffect(() => {
    fetch('https://api.frankfurter.app/latest?from=EUR&to=ALL')
      .then((r) => r.json())
      .then((d) => setRate(d.rates.ALL))
      .catch(() => setRate(103)); // fallback rate
  }, []);

  const eurValue = parseFloat(amount) || 0;
  const lekValue = rate ? (eurValue * rate).toFixed(0) : '...';

  return (
    <div className="pb-24">
      <TopBar title="Info Praktike" subtitle="Gjithçka për udhëtimin tënd" />

      {/* SOS */}
      <div className="px-4 -mt-3">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <p className="font-bold text-gray-700 flex items-center gap-1 mb-3">
            <ShieldAlert size={16} className="text-red-500" /> Numra Urgjence
          </p>
          <div className="grid grid-cols-3 gap-2">
            {emergencyNumbers.map((e) => (
              <a
                key={e.number}
                href={`tel:${e.number}`}
                className="bg-red-50 rounded-xl p-3 text-center"
              >
                <Phone size={16} className="mx-auto text-red-500 mb-1" />
                <p className="text-xs text-gray-600">{e.label}</p>
                <p className="font-bold text-red-600">{e.number}</p>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Konvertues valute */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <p className="font-bold text-gray-700 flex items-center gap-1 mb-3">
            <ArrowLeftRight size={16} className="text-[var(--color-adriatic)]" /> Konvertues Valute
          </p>
          <div className="flex items-center gap-2">
            <div className="flex-1">
              <label className="text-xs text-gray-400">EUR</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
              />
            </div>
            <ArrowLeftRight size={16} className="text-gray-300 mt-4" />
            <div className="flex-1">
              <label className="text-xs text-gray-400">Lekë</label>
              <div className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50">
                {lekValue}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fraza bazë */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <p className="font-bold text-gray-700 flex items-center gap-1 mb-3">
            <MessageCircle size={16} className="text-[var(--color-adriatic)]" /> Fraza Bazë Shqip
          </p>
          <div className="space-y-2">
            {phrases.map((p) => (
              <div key={p.sq} className="flex justify-between text-sm">
                <span className="font-medium text-gray-700">{p.sq}</span>
                <span className="text-gray-400">{p.en}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* WiFi & Siguri */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <p className="font-bold text-gray-700 flex items-center gap-1 mb-3">
            <Wifi size={16} className="text-[var(--color-adriatic)]" /> Këshilla & Siguri
          </p>
          <ul className="space-y-2 text-sm text-gray-600 list-disc list-inside">
            {safetyTips.map((t, i) => (
              <li key={i}>{t}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
