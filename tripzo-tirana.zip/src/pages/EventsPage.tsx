import TopBar from '../components/TopBar';
import { events } from '../data/events';
import { CalendarDays, MapPin, Ticket } from 'lucide-react';

export default function EventsPage() {
  return (
    <div className="pb-24">
      <TopBar title="Argëtim" subtitle="Teatro, koncerte & festivale" />

      <div className="px-4 mt-4 grid gap-4">
        {events.map((ev) => (
          <div key={ev.id} className="bg-white rounded-2xl overflow-hidden shadow-sm flex">
            <img src={ev.image} alt={ev.title} className="w-28 h-full object-cover shrink-0" />
            <div className="p-3 flex-1">
              <span className="text-[10px] uppercase tracking-wide font-bold text-[var(--color-adriatic)]">
                {ev.category}
              </span>
              <h3 className="font-bold text-gray-800 text-sm mt-0.5">{ev.title}</h3>
              <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                <MapPin size={12} /> {ev.venue}
              </p>
              <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                <CalendarDays size={12} /> {ev.date} · {ev.time}
              </p>
              <p className="text-xs font-semibold text-gray-700 flex items-center gap-1 mt-1">
                <Ticket size={12} /> {ev.priceLek === 'falas' ? 'Falas' : `${ev.priceLek} Lekë`}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
