import { useMemo, useState } from 'react';
import { Heart, MapPin, Star } from 'lucide-react';
import TopBar from '../components/TopBar';
import { foodPlaces } from '../data/foodPlaces';
import { useFavorites } from '../lib/useFavorites';
import type { FoodPlace } from '../types';

const typeFilters: { key: FoodPlace['type'] | 'all'; label: string }[] = [
  { key: 'all', label: 'Të gjitha' },
  { key: 'restorant', label: 'Restorante' },
  { key: 'kafe', label: 'Kafe' },
  { key: 'klub', label: 'Klube' },
];

const priceLabel = (p: number) => '€'.repeat(p);

export default function FoodPage() {
  const [type, setType] = useState<FoodPlace['type'] | 'all'>('all');
  const { toggleFavorite, isFavorite } = useFavorites();

  const filtered = useMemo(
    () => (type === 'all' ? foodPlaces : foodPlaces.filter((f) => f.type === type)),
    [type]
  );

  return (
    <div className="pb-24">
      <TopBar title="Ha & Pi" subtitle="Restorante, kafe & klube" />

      <div className="px-4 -mt-3 flex gap-2 overflow-x-auto pb-1">
        {typeFilters.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t.key)}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium shadow-sm transition-colors ${
              type === t.key ? 'bg-[var(--color-adriatic)] text-white' : 'bg-white text-gray-600'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4 grid gap-4">
        {filtered.map((place) => (
          <div key={place.id} className="bg-white rounded-2xl overflow-hidden shadow-sm">
            <div className="relative">
              <img src={place.image} alt={place.name} className="w-full h-36 object-cover" />
              <button
                onClick={() => toggleFavorite(place.id)}
                className="absolute top-3 right-3 bg-white/90 rounded-full p-2"
              >
                <Heart
                  size={16}
                  className={isFavorite(place.id) ? 'fill-[var(--color-sunset)] text-[var(--color-sunset)]' : 'text-gray-400'}
                />
              </button>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-800">{place.name}</h3>
                <span className="flex items-center gap-1 text-xs text-gray-500">
                  <Star size={12} className="fill-yellow-400 text-yellow-400" /> {place.rating}
                </span>
              </div>
              <p className="text-sm text-gray-500 mt-1">{place.cuisine}</p>
              <div className="flex gap-3 mt-3 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <MapPin size={12} /> {place.zone}
                </span>
                <span>{priceLabel(place.price)}</span>
                <span className="capitalize">{place.vibe}</span>
              </div>
              <p className="text-xs text-gray-400 mt-2">Orari: {place.hours}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
