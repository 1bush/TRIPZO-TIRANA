import { NavLink } from 'react-router-dom';
import { Bus, Compass, UtensilsCrossed, Ticket, MapPinned, LifeBuoy } from 'lucide-react';

const tabs = [
  { to: '/', label: 'Transporti', icon: Bus },
  { to: '/eksploro', label: 'Eksploro', icon: Compass },
  { to: '/ha-pi', label: 'Ha & Pi', icon: UtensilsCrossed },
  { to: '/argetim', label: 'Argëtim', icon: Ticket },
  { to: '/itinerare', label: 'Itinerare', icon: MapPinned },
  { to: '/info', label: 'Info', icon: LifeBuoy },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 z-50 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      {tabs.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/'}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium flex-1 h-full transition-colors ${
              isActive ? 'text-[var(--color-adriatic)]' : 'text-gray-400'
            }`
          }
        >
          <Icon size={20} strokeWidth={2.2} />
          <span>{label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
