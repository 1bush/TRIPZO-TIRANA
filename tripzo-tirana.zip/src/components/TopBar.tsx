import { useEffect, useState } from 'react';
import { Sun, CloudSun, Cloud, CloudRain } from 'lucide-react';

interface Props {
  title: string;
  subtitle?: string;
}

interface WeatherData {
  temp: number;
  code: number;
}

function iconFor(code: number) {
  if (code === 0) return Sun;
  if (code <= 3) return CloudSun;
  if (code <= 48) return Cloud;
  return CloudRain;
}

export default function TopBar({ title, subtitle }: Props) {
  const [weather, setWeather] = useState<WeatherData | null>(null);

  useEffect(() => {
    // Tirana coords, Open-Meteo (falas, pa API key)
    fetch(
      'https://api.open-meteo.com/v1/forecast?latitude=41.3275&longitude=19.8187&current=temperature_2m,weather_code'
    )
      .then((r) => r.json())
      .then((d) =>
        setWeather({ temp: Math.round(d.current.temperature_2m), code: d.current.weather_code })
      )
      .catch(() => setWeather(null));
  }, []);

  const WeatherIcon = weather ? iconFor(weather.code) : Sun;

  return (
    <div className="bg-[var(--color-adriatic)] text-white px-5 pt-6 pb-4 rounded-b-3xl">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          {subtitle && <p className="text-sm text-white/80 mt-0.5">{subtitle}</p>}
        </div>
        {weather && (
          <div className="flex items-center gap-1 bg-white/15 rounded-full px-3 py-1.5">
            <WeatherIcon size={16} />
            <span className="text-sm font-semibold">{weather.temp}°C</span>
          </div>
        )}
      </div>
    </div>
  );
}
