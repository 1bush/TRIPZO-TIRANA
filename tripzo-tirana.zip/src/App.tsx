import { HashRouter, Routes, Route } from 'react-router-dom';
import BottomNav from './components/BottomNav';
import TransportPage from './pages/TransportPage';
import ExplorePage from './pages/ExplorePage';
import FoodPage from './pages/FoodPage';
import EventsPage from './pages/EventsPage';
import ItineraryPage from './pages/ItineraryPage';
import InfoPage from './pages/InfoPage';

export default function App() {
  return (
    <HashRouter>
      <div className="max-w-md mx-auto min-h-screen bg-[var(--color-cream)] relative">
        <Routes>
          <Route path="/" element={<TransportPage />} />
          <Route path="/eksploro" element={<ExplorePage />} />
          <Route path="/ha-pi" element={<FoodPage />} />
          <Route path="/argetim" element={<EventsPage />} />
          <Route path="/itinerare" element={<ItineraryPage />} />
          <Route path="/info" element={<InfoPage />} />
        </Routes>
        <BottomNav />
      </div>
    </HashRouter>
  );
}
