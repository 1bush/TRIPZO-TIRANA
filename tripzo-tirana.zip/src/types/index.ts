export interface BusStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
}

export interface BusLine {
  id: string;
  number: string;
  name: string;
  color: string;
  from: string;
  to: string;
  firstDeparture: string;
  lastDeparture: string;
  avgWaitMin: number;
  priceLek: number;
  stops: BusStop[];
}

export type POICategory = 'histori' | 'natyre' | 'art' | 'familje';

export interface POI {
  id: string;
  name: string;
  category: POICategory;
  description: string;
  lat: number;
  lng: number;
  priceInfo: string;
  hours: string;
  image: string;
  rating: number;
}

export type FoodVibe = 'romantik' | 'familjar' | 'nightlife' | 'casual';
export type PriceLevel = 1 | 2 | 3;

export interface FoodPlace {
  id: string;
  name: string;
  type: 'restorant' | 'kafe' | 'klub';
  zone: string;
  cuisine: string;
  price: PriceLevel;
  vibe: FoodVibe;
  hours: string;
  lat: number;
  lng: number;
  image: string;
  rating: number;
}

export interface EventItem {
  id: string;
  title: string;
  category: 'teatro' | 'kinema' | 'koncert' | 'festival';
  venue: string;
  date: string;
  time: string;
  priceLek: number | 'falas';
  image: string;
}

export interface ItineraryStop {
  time: string;
  itemId: string;
  itemType: 'poi' | 'food' | 'event';
  note?: string;
}

export interface Itinerary {
  id: string;
  title: string;
  days: number;
  stops: ItineraryStop[][];
}
